# Bitcoin ARIMA 时间序列建模

基于 R 语言的比特币月度价格 ARIMA(p,d,q) 建模与预测项目。采用经典的 Box-Jenkins 方法论，对 2014 年 9 月至 2026 年 5 月的比特币日度价格数据进行系统的时间序列分析，完成从数据预处理、平稳性检验、模型识别、参数估计、模型诊断到最终预测的完整流程。

## 项目概述

本项目对比特币市场价格进行建模，核心目标包括：

1. **数据预处理**：将日度价格数据重采样为月度均价
2. **平稳性检验**：通过 ADF 单位根检验确定差分阶数 d
3. **模型识别**：结合 ACF/PACF 图与疏系数方法识别最优 ARIMA 模型
4. **参数估计**：系统拟合 16 个 ARIMA(p,1,q) 候选模型（p,q ∈ {0,1,2,3}）
5. **模型诊断**：残差白噪声检验与参数显著性检验
6. **模型优化**：基于 AIC/BIC/AICc 准则选择最优模型
7. **价格预测**：对未来 3 期进行点预测与区间预测

## 项目结构

```
├── bitcoin_btc.csv          # 比特币日度价格数据（2014/9 - 2026/5）
├── bitcoin_arima_modeling.R # 完整的 R 分析脚本
├── figures/                 # 分析结果图表
│   ├── fig1_1_original_time_series.png   # 原始月度均价时序图
│   ├── fig1_2_original_acf.png           # 原始序列 ACF 图
│   ├── fig2_1_diff1_time_series.png      # 一阶差分时序图
│   ├── fig2_2_diff1_acf.png              # 一阶差分 ACF 图
│   ├── fig2_3_diff2_time_series.png      # 二阶差分时序图
│   ├── fig2_4_diff2_acf.png              # 二阶差分 ACF 图
│   ├── fig3_1_diff1_acf.png              # 一阶差分后 ACF 图
│   ├── tsdiag_ARIMA*.png                 # 各模型残差诊断图
│   └── fig8_1_forecast.png               # 历史价格与未来预测对比图
└── Bitcoin_Price_ARIMA_TimeSeries_Forecast_Report.docx  # 详细分析报告
```

## 技术栈

- **编程语言**：R
- **核心包**：
  - `readr` — CSV 数据读取
  - `tseries` — ADF 单位根检验
  - `aTSA` — ADF 检验（Type1/2/3）
  - `forecast` — ARIMA 建模与预测

## 快速开始

### 环境要求

- R ≥ 4.0
- 上述四个 R 包

### 运行步骤

```r
# 1. 安装依赖包（如尚未安装）
install.packages(c("readr", "tseries", "aTSA", "forecast"))

# 2. 加载包
library(readr)
library(tseries)
library(aTSA)
library(forecast)

# 3. 运行完整脚本
source("bitcoin_arima_modeling.R")
```

脚本将自动执行全部分析流程，在控制台输出各模型的结果摘要，并在 `figures/` 目录下生成所有分析图表。

## 分析方法

### 数据预处理

原始数据为日度收盘价，按自然月分组计算月均价，得到约 140 个月度观测值。

### 平稳性检验

使用 Augmented Dickey-Fuller (ADF) 单位根检验判断序列的平稳性：

| 序列 | ADF p 值 | 结论 |
|------|----------|------|
| 原始序列 | > 0.05 | 非平稳 |
| 一阶差分 | < 0.05 | 平稳 |
| 二阶差分 | < 0.05 | 平稳 |

确认差分阶数 **d = 1**。

### 模型识别

对一阶差分后序列绘制 ACF 和 PACF 图，发现两者均呈现拖尾特征，因此使用 ARMA(p,q) 模型，即 ARIMA(p,1,q)。

### 参数估计

穷举搜索 p ∈ {0,1,2,3}、q ∈ {0,1,2,3} 共 16 个组合，采用最大似然法（ML）估计参数，记录每个模型的 AIC和 BIC 值。

### 模型诊断

- **残差白噪声检验**：Ljung-Box 检验（滞后 6 阶和 12 阶），p > 0.05 表示残差为白噪声，模型充分
- **参数显著性检验**：计算各参数的 t 统计量和 p 值，筛选出所有参数均显著的模型
- **疏系数模型**：对部分参数不显著的模型，将不显著参数固定为 0 后重新拟合

### 模型选择

综合 AIC、BIC 两个信息准则，最终选定 **ARIMA(2,1,3)** 为最优模型。

### 预测

基于最优模型对未来 3 个月进行预测，同时给出 80% 和 95% 置信区间。

## 主要结果

最优模型为 **ARIMA(2,1,3)**，模型方程为：

$$\phi(B)(1-B)Y_t = \theta(B)\varepsilon_t$$

其中：
- $\phi(B) = (1 - \phi_1 B - \phi_2 B^2)$ 为 AR(2) 部分
- $\theta(B) = (1 + \theta_1 B + \theta_2 B^2 + \theta_3 B^3)$ 为 MA(3) 部分
- $(1-B)$ 为一阶差分算子

## 可视化成果

脚本生成的图表包括：

- 原始序列与时序变化趋势
- 各差分阶数下的 ACF 图
- 差分后序列的 ACF/PACF 图（用于定阶）
- 16 个候选模型的残差诊断图（时序图 + ACF + Ljung-Box 检验）
- 最优模型的预测对比图（历史数据 + 预测值 + 置信区间）


