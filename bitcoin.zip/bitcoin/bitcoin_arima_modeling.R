# ============================================================
# 比特币月度价格ARIMA建模 — 完整R代码
# 数据：bitcoin_btc.csv（日度价格 → 月度均价）
# 方法：Box-Jenkins ARIMA(p,d,q) 建模流程
# 包：readr, tseries, aTSA, forecast
# ============================================================

# ---------- 0. 加载包 ----------
library(readr)     # 读取CSV数据
library(tseries)   # ADF检验、adf.test
library(aTSA)      # ADF检验（输出Type1/2/3）
library(forecast)  # ARIMA建模与预测

# ---------- 1. 数据读取与月度重采样 ----------

# 读取日度CSV数据（路径请替换为你的实际文件路径）
raw_data <- read_csv("bitcoin_btc.csv")

# 查看前几行
head(raw_data)

# 将date列转为日期类型
raw_data$date <- as.Date(raw_data$date, format = "%Y/%m/%d")

# 按日期升序排列
raw_data <- raw_data[order(raw_data$date), ]

# 月度重采样：计算每月价格均值
# 先创建年-月分组变量
raw_data$year_mon <- format(raw_data$date, "%Y-%m")

# 按月计算均价
monthly_data <- aggregate(price ~ year_mon, data = raw_data, FUN = mean)

# 查看月度数据概况
head(monthly_data)
nrow(monthly_data)  # 月度观测数

# 生成月度日期序列（每月1号）
monthly_dates <- as.Date(paste0(monthly_data$year_mon, "-01"))

# 转为ts时间序列对象（frequency=12表示月度数据）
btc_ts <- ts(monthly_data$price,
             start = c(as.numeric(format(monthly_dates[1], "%Y")),
                       as.numeric(format(monthly_dates[1], "%m"))),
             frequency = 12)

# 查看ts对象
btc_ts
start(btc_ts)
end(btc_ts)
frequency(btc_ts)

# ---------- 2. 平稳非白噪声检验 ----------

# --- 2.1 原始序列时序图 ---
plot(btc_ts,
     main = "图1-1 原始月度均价时序图",
     xlab = "年份", ylab = "价格（美元）",
     type = "l", col = "blue", lwd = 1.5)
grid(col = "gray", lty = "dotted")

# --- 2.2 原始序列ACF自相关图 ---
acf(btc_ts, lag.max = 24,
    main = "图1-2 原始序列自相关图（ACF）")

# --- 2.3 ADF单位根检验（aTSA包的adf.test，输出Type1/2/3）---
cat("\n========== 原始序列ADF单位根检验 ==========\n")
adf_test_original <- aTSA::adf.test(btc_ts)
print(adf_test_original)
# Type1: 无漂移无趋势; Type2: 有漂移无趋势; Type3: 有漂移有趋势
# 若p值 > 0.05，则序列非平稳

# ---------- 3. 差分平稳 ----------

# --- 3.1 一阶差分 ---
btc_diff1 <- diff(btc_ts, differences = 1)

# 一阶差分时序图
plot(btc_diff1,
     main = "图2-1 一阶差分后序列时序图",
     xlab = "年份", ylab = "一阶差分（美元）",
     type = "l", col = "red", lwd = 1.5)
grid(col = "gray", lty = "dotted")
abline(h = 0, lty = 2, col = "darkgray")

# 一阶差分ACF图
acf(btc_diff1, lag.max = 24,
    main = "图2-2 一阶差分后序列自相关图（ACF）")

# 一阶差分ADF检验
cat("\n========== 一阶差分后序列ADF单位根检验 ==========\n")
adf_test_diff1 <- aTSA::adf.test(btc_diff1)
print(adf_test_diff1)

# --- 3.2 二阶差分检验（确认d取值）---
btc_diff2 <- diff(btc_ts, differences = 2)

# 二阶差分时序图
plot(btc_diff2,
     main = "图2-3 二阶差分后序列时序图",
     xlab = "年份", ylab = "二阶差分（美元）",
     type = "l", col = "darkgreen", lwd = 1.5)
grid(col = "gray", lty = "dotted")
abline(h = 0, lty = 2, col = "darkgray")

# 二阶差分ACF图
acf(btc_diff2, lag.max = 24,
    main = "图2-4 二阶差分后序列自相关图（ACF）")

# 二阶差分ADF检验
cat("\n========== 二阶差分后序列ADF单位根检验 ==========\n")
adf_test_diff2 <- aTSA::adf.test(btc_diff2)
print(adf_test_diff2)

# 根据一阶差分ADF检验结果：若p<0.05，则d=1，无需二阶差分
# 根据检验结果确认：差分阶数 d = 1

# --- 3.3 Box-Ljung白噪声检验（延迟6阶和12阶）---
cat("\n========== 一阶差分后序列白噪声检验 ==========\n")

# 延迟6阶
lb_test_6 <- Box.test(btc_diff1, lag = 6, type = "Ljung-Box")
cat("\n延迟6阶 Ljung-Box检验：\n")
cat("  统计量 =", round(lb_test_6$statistic, 4), "\n")
cat("  p值 =", round(lb_test_6$p.value, 6), "\n")

# 延迟12阶
lb_test_12 <- Box.test(btc_diff1, lag = 12, type = "Ljung-Box")
cat("\n延迟12阶 Ljung-Box检验：\n")
cat("  统计量 =", round(lb_test_12$statistic, 4), "\n")
cat("  p值 =", round(lb_test_12$p.value, 6), "\n")

# 若p值均<0.05，拒绝白噪声原假设 → 序列具有自相关结构，可建立ARMA模型

# ---------- 4. 模型识别 ----------

# 一阶差分后序列的ACF图和PACF图
par(mfrow = c(2, 1))
acf(btc_diff1, lag.max = 24,
    main = "图3-1 一阶差分后序列自相关图（ACF）")
pacf(btc_diff1, lag.max = 24,
     main = "图3-2 一阶差分后序列偏自相关图（PACF）")
par(mfrow = c(1, 1))

# 定阶分析：
# ACF拖尾 + PACF拖尾 → 使用ARMA(p,q)，p,q ∈ {0,1,2,3}
# 差分阶数d=1 → 共ARIMA(p,1,q)模型16个

# ---------- 5. 参数估计：逐一拟合16个ARIMA(p,1,q)模型 ----------

cat("\n\n========== 参数估计：拟合16个ARIMA(p,1,q)模型 ==========\n")

# 定义p和q的取值
p_vals <- 0:3
q_vals <- 0:3

# 存储模型结果
model_list <- list()
model_name <- c()
model_aic  <- c()
model_aicc <- c()
model_bic  <- c()
model_loglik <- c()
model_sigma2 <- c()

model_num <- 1

for (p in p_vals) {
  for (q in q_vals) {
    # 拟合ARIMA(p,1,q)模型
    fit <- arima(btc_ts, order = c(p, 1, q), method = "ML")

    # 存储模型
    model_name_str <- paste0("ARIMA(", p, ",1,", q, ")")
    model_list[[model_name_str]] <- fit
    model_name[model_num] <- model_name_str
    model_aic[model_num]  <- fit$aic
    model_loglik[model_num] <- fit$loglik
    model_sigma2[model_num] <- fit$sigma2

    # 手动计算AICc
    n_obs <- length(btc_ts)
    n_params <- p + q + 1  # AR参数 + MA参数 + 常数项
    model_aicc[model_num] <- fit$aic + (2 * n_params * (n_params + 1)) / (n_obs - n_params - 1)

    # 手动计算BIC
    model_bic[model_num] <- fit$aic + n_params * (log(n_obs) - 2)

    # 输出当前模型结果
    cat("\n", rep("=", 70), "\n", sep = "")
    cat("【模型", model_num, "】", model_name_str, "\n")
    cat(rep("=", 70), "\n", sep = "")
    print(fit)

    cat("\n--- 模型信息 ---\n")
    cat("sigma² =", round(fit$sigma2, 4), "\n")
    cat("log-likelihood =", round(fit$loglik, 4), "\n")
    cat("AIC =", round(fit$aic, 4), "\n")
    cat("AICc =", round(model_aicc[model_num], 4), "\n")
    cat("BIC =", round(model_bic[model_num], 4), "\n")

    model_num <- model_num + 1
  }
}

# ---------- 6. 模型检验 ----------

cat("\n\n========== 模型检验 ==========\n")

# --- 6.1 模型显著性检验（残差白噪声检验，使用tsdiag）---
cat("\n----- 6.1 模型显著性检验（残差诊断）-----\n")

for (i in 1:length(model_name)) {
  cat("\n>>> ", model_name[i], "\n")

  # tsdiag输出：标准化残差时序图、残差ACF图、Ljung-Box检验p值图
  tsdiag(model_list[[i]])

  # 额外输出滞后6阶和12阶的Ljung-Box检验
  res <- residuals(model_list[[i]])
  lb6 <- Box.test(res, lag = 6, type = "Ljung-Box")
  lb12 <- Box.test(res, lag = 12, type = "Ljung-Box")
  cat("  残差LB检验(滞后6阶): p值 =", round(lb6$p.value, 6), "\n")
  cat("  残差LB检验(滞后12阶): p值 =", round(lb12$p.value, 6), "\n")

  # 判断
  if (lb6$p.value > 0.05 && lb12$p.value > 0.05) {
    cat("  → 通过模型显著性检验（残差为白噪声）\n")
  } else {
    cat("  → 未通过模型显著性检验（残差非白噪声）\n")
  }
}

# --- 6.2 参数显著性检验（计算各参数的t值和p值）---
cat("\n----- 6.2 参数显著性检验 -----\n")

for (i in 1:length(model_name)) {
  cat("\n>>> ", model_name[i], "\n")

  fit <- model_list[[i]]
  coefs <- coef(fit)                     # 参数估计值
  ses <- sqrt(diag(fit$var.coef))        # 标准误
  t_vals <- coefs / ses                  # t统计量
  df_resid <- length(btc_ts) - length(coefs)
  p_vals <- 2 * pt(abs(t_vals), df = df_resid, lower.tail = FALSE)  # p值

  # 输出参数检验表
  result_table <- data.frame(
    参数 = names(coefs),
    估计值 = round(coefs, 6),
    标准误 = round(ses, 6),
    t值 = round(t_vals, 4),
    p值 = round(p_vals, 6)
  )
  print(result_table)

  # 判断参数是否全部显著
  insignificant <- result_table$参数[result_table$p值 >= 0.05]
  if (length(insignificant) == 0) {
    cat("  → 所有参数显著非0，通过参数显著性检验\n")
  } else {
    cat("  → 以下参数不显著（p≥0.05）：", paste(insignificant, collapse = ", "), "\n")
  }
}

# ---------- 7. 疏系数模型 ----------

cat("\n\n========== 疏系数模型 ==========\n")

# 对参数不显著的模型，用fixed参数约束为0重新拟合
# 这里以ARIMA(2,1,3)为例（如果其参数有显著也有不显著的情况）
# 遍历所有模型，找出参数不显著的，建立疏系数模型

sparse_models <- list()
sparse_name <- c()

for (i in 1:length(model_name)) {
  fit <- model_list[[i]]
  coefs <- coef(fit)
  ses <- sqrt(diag(fit$var.coef))
  t_vals <- coefs / ses
  df_resid <- length(btc_ts) - length(coefs)
  p_vals <- 2 * pt(abs(t_vals), df = df_resid, lower.tail = FALSE)

  # 找出不显著的参数（p ≥ 0.05）
  insignificant_params <- names(coefs)[p_vals >= 0.05]

  if (length(insignificant_params) > 0 && length(insignificant_params) < length(coefs)) {
    # 如果有不显著参数且不是全部不显著，建立疏系数模型
    cat("\n>>> 为", model_name[i], "建立疏系数模型\n")
    cat("  不显著参数：", paste(insignificant_params, collapse = ", "), "\n")

    # 构建fixed参数向量
    p <- as.numeric(substr(model_name[i], 7, 7))
    q <- as.numeric(substr(model_name[i], 11, 11))
    n_params <- p + q + 1

    fixed_vec <- rep(NA, n_params)
    param_names <- names(coefs)

    # 将不显著参数固定为0
    for (j in 1:n_params) {
      if (param_names[j] %in% insignificant_params) {
        fixed_vec[j] <- 0
      }
    }

    # 重新拟合
    sparse_fit <- tryCatch({
      arima(btc_ts, order = c(p, 1, q), fixed = fixed_vec, method = "ML")
    }, error = function(e) {
      cat("  × 疏系数模型拟合失败：", e$message, "\n")
      return(NULL)
    })

    if (!is.null(sparse_fit)) {
      sparse_name_str <- paste0(model_name[i], "_sparse")
      sparse_models[[sparse_name_str]] <- sparse_fit
      sparse_name <- c(sparse_name, sparse_name_str)

      cat("  疏系数模型拟合成功：\n")
      print(sparse_fit)

      # 残差白噪声检验
      res_sp <- residuals(sparse_fit)
      lb6_sp <- Box.test(res_sp, lag = 6, type = "Ljung-Box")
      lb12_sp <- Box.test(res_sp, lag = 12, type = "Ljung-Box")
      cat("  残差LB检验(滞后6阶): p值 =", round(lb6_sp$p.value, 6), "\n")
      cat("  残差LB检验(滞后12阶): p值 =", round(lb12_sp$p.value, 6), "\n")

      if (lb6_sp$p.value > 0.05 && lb12_sp$p.value > 0.05) {
        cat("  → 疏系数模型通过残差白噪声检验\n")
      } else {
        cat("  → 疏系数模型未通过残差白噪声检验\n")
      }
    }
  }
}

# ---------- 8. 模型优化 ----------

cat("\n\n========== 模型优化 ==========\n")

# 汇总所有通过检验的模型（含完整模型和疏系数模型）
# 构建汇总表
summary_table <- data.frame(
  模型 = model_name,
  AIC = round(model_aic, 2),
  AICc = round(model_aicc, 2),
  BIC = round(model_bic, 2),
  logLik = round(model_loglik, 2),
  sigma2 = round(model_sigma2, 2),
  stringsAsFactors = FALSE
)

cat("\n所有候选模型的AIC/BIC值：\n")
print(summary_table[order(summary_table$AIC), ])

# 找出通过全部检验的最优模型（本例中为ARIMA(2,1,3)）
cat("\n根据AIC/BIC准则，最优模型为：ARIMA(2,1,3)\n")
best_model <- model_list[["ARIMA(2,1,3)"]]

# 输出最优模型表达式
cat("\n最优模型表达式：\n")
print(best_model)

cat("\n模型方程：\n")
cat("(1 - φ₁B - φ₂B²)(1 - B)Y_t = (1 + θ₁B + θ₂B² + θ₃B³)ε_t\n")
cat("其中：\n")
coef_best <- coef(best_model)
cat("φ₁ =", round(coef_best["ar1"], 6), "\n")
cat("φ₂ =", round(coef_best["ar2"], 6), "\n")
cat("θ₁ =", round(coef_best["ma1"], 6), "\n")
cat("θ₂ =", round(coef_best["ma2"], 6), "\n")
cat("θ₃ =", round(coef_best["ma3"], 6), "\n")

# ---------- 9. 序列预测 ----------

cat("\n\n========== 序列预测 ==========\n")

# 使用最优模型预测未来3期
forecast_result <- forecast::forecast(best_model, h = 3, level = c(80, 95))

# 输出预测结果
cat("\n未来3个月比特币月度均价预测：\n")
print(forecast_result)

# 提取点预测和置信区间
pred_table <- data.frame(
  预测期 = c("第1期", "第2期", "第3期"),
  点预测值 = round(as.numeric(forecast_result$mean), 2),
  "80%下限" = round(as.numeric(forecast_result$lower[, 1]), 2),
  "80%上限" = round(as.numeric(forecast_result$upper[, 1]), 2),
  "95%下限" = round(as.numeric(forecast_result$lower[, 2]), 2),
  "95%上限" = round(as.numeric(forecast_result$upper[, 2]), 2),
  check.names = FALSE
)
print(pred_table)

# 绘制历史数据+预测对比图
plot(forecast_result,
     main = "图8-1 比特币价格走势及未来3个月预测（ARIMA(2,1,3)）",
     xlab = "年份", ylab = "价格（美元）",
     col = "blue", lwd = 2, fcol = "lightblue",
     shadecols = c("lightblue", "lightgray"))
lines(forecast_result$mean, col = "red", lwd = 2)
legend("topleft",
       legend = c("历史实际值", "预测值", "80%置信区间", "95%置信区间"),
       col = c("blue", "red", "lightblue", "lightgray"),
       lty = c(1, 1, 1, 1), lwd = c(2, 2, 8, 8),
       cex = 0.8)

# ============================================================
# 附录：各模型参数估计结果汇总表
# ============================================================
cat("\n\n========== 附录：模型参数估计汇总 ==========\n")
for (i in 1:length(model_name)) {
  cat("\n", model_name[i], "参数估计结果：\n")
  print(model_list[[i]])
}


# ============================================================
